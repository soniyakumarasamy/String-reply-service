package com.springreplyservice.springservice;

import com.springreplyservice.springservice.controller.SpringTask;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;


@WebMvcTest(SpringTask.class)
public class SpringTaskTest{

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void helloWorld() throws Exception {
        ResultActions helloworld = mockMvc.perform(MockMvcRequestBuilders.get("/hello-world"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().string("helloworld"));
    }
}
