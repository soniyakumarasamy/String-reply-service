package com.springreplyservice.springservice.controller;

import org.springframework.web.bind.annotation.*;
import com.springreplyservice.springservice.service.SpringTaskService;


@RestController
@CrossOrigin
@RequestMapping("/v2/reply")
public class SpringTask {

    @GetMapping("/hello-world")
    public String helloWorld() {
               return "helloworld";
    }

    @GetMapping ("/{input}")
    public String stringReturn(@PathVariable String input) {

        SpringTaskService taskService = new SpringTaskService();
        String data=taskService.inputstring(input);
        return data;
    }

}
