package com.springreplyservice.springservice.service;
import org.springframework.stereotype.Service;

@Service
public class SpringTaskService {

    public String inputstring( String inputstring){

        if (inputstring != null) {
           String[] index = inputstring.split("-");
                if (index.length >= 2) {
                String supportnums = index[0];
                String input = index[1];
                String transformedString = SpringApplyrules.applyRules(input, supportnums);
                System.out.println("Transformed string: " + transformedString);
                return  transformedString;
            } else {
                return "Invalid input format";
            }
        } else {

            return "Input is null";
        }

    }

}

