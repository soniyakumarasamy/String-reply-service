package com.springreplyservice.springservice.service;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;


public class SpringApplyrules {
    public static String applyRules(String input, String supportnums) {

        for (char supportnum : supportnums.toCharArray()) {
            if (supportnum == '1') {
                input = reverseString(input);
            } else if (supportnum == '2') {
                input = md5Hash(input);
            }
            else {
                return "Invalid input";
            }
        }
        return input;
    }

    private static String reverseString(String input) {
        return new StringBuilder(input).reverse().toString();
    }

    private static String md5Hash(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] messageDigest = md.digest(input.getBytes());
            BigInteger no = new BigInteger(1, messageDigest);
            StringBuilder hashText = new StringBuilder(no.toString(16));
            while (hashText.length() < 32) {
                hashText.insert(0, "0");
            }
            return hashText.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }
    
}
